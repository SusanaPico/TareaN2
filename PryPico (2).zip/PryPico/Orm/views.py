from django.shortcuts import render

# Create your views her.e
# from Orm.models import Producto
#
# P1 = Producto(descripcion='Aceite Girazol', precio=1.50, stock=2000, iva=True)
#
# Producto.objects.all()
#
# from Orm.models import Producto
#
# P1 = Producto(descripcion='Aceite Girazol', precio=1.50, stock=2000, iva=True)
# P1.save()
# P2 = Producto.objects.create(descripcion='Coca Cola', precio=0.90, stock=10000, iva=True)
# P2.save()
# from Orm.models import Producto, Factura, Cliente, DetalleFactura
#
# c1 = Cliente.objects.create(ruc='0989214288', nombre='Roxanna Loor', direccion='Quito y Chimbo')
# c1.producto.add(P1)
# c1.producto.add(P2)
# c2 = Cliente.objects.create(ruc='096523654', nombre='Maribí Zerna', direccion='Guayaquil y Naranjito')
# c2.producto.add(P1)
# c2.producto.add(P2)
# product = Producto.objects.get(id=2)
# product = Producto.objects.filter(id=2)
# Producto.objects.filter(id=2)
#
# Producto.objects.filter(id=2)
#
# Producto.objects.filter(id=2)
