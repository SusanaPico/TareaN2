from django.apps import AppConfig


class OrmConfig(AppConfig):
    name = 'Orm'
