from django.shortcuts import render

# Create your views her.e
from Orm.models import Producto,Factura, Cliente, DetalleFactura
#1
P1 = Producto(descripcion='Aceite Girazol', precio=1.50, stock=2000, iva=True)
P1.save()
P2 = Producto.objects.create(descripcion='Coca Cola', precio=0.90, stock=10000, iva=True)

#2
c1 = Cliente.objects.create(ruc='0989214288', nombre='Roxanna Loor', direccion='Quito y Chimbo')
c1.producto.add(P1)
c1.producto.add(P2)
c2 = Cliente.objects.create(ruc='096523654', nombre='Maribí Zerna', direccion='Guayaquil y Naranjito')
c2.producto.add(P1)
c2.producto.add(P2)
#3
F1 = Factura()
F1 = Factura(cliente=c1,fecha='2020-08-01',total=20)
F1.save()
F2 = Factura(cliente=c2,fecha='2020-07-01',total=30)
F2.save()

#4
DF1 = DetalleFactura(factura=F1,producto=P1,cantidad=3,precio=float(P1.precio),subtotal=19)
DF1.save()

DF2 = DetalleFactura(factura=F2,producto=P2,cantidad=4,precio=float(P2.precio),subtotal=28)
DF2.save()
#presentar todo
Cliente.objects.all()
Producto.objects.all()
Factura.objects.all()
DetalleFactura.objects.all()

#Modificar
#1
P1=Producto.objects.get(id=1)
P1.precio=1.6
P1.save()

Producto.objects.filter(id=1).update(precio=1.7)
#2 Cliente
c1=Cliente.objects.get(id=1)

print(c1)
c1.nombre='Neiser Valenzuela'
c1.save()
c1=Cliente.objects.get(id=1)
print(c1)

c2=Cliente.objects.get(id=2)
print(c2)
c2.nombre='Marlene Oquendo'
c2.save()
c1=Cliente.objects.get(id=1)
print(c2)

# #
from Orm.models import Producto,Factura, Cliente, DetalleFactura
P1=Producto.objects.get(id=1)
P2=Producto.objects.get(id=2)
c1=Cliente.objects.get(id=1)
c2=Cliente.objects.get(id=2)
F1=Factura.objects.get(id=1)
F2=Factura.objects.get(id=2)
DF1=DetalleFactura.objects.get(id=1)
DF2=DetalleFactura.objects.get(id=2)

#Quereset
Producto.objects.all()

P2= Producto.objects.get(id=2)
print(P2)
Producto.objects.filter(id__lte=2)
Producto.objects.filter(id__lte=1)
Producto.objects.exclude(descripcion__icontains='Cola')
Producto.objects.filter(id__gte=4)
Producto.objects.filter(id__gt=4).values('id','descripcion')
Producto.objects.filter(id__lt=4).values('id','descripcion')
Producto.objects.filter(descripcion='Coca Cola').values('id','descripcion')
